const { MongoClient } = require('mongodb');

// MongoDB connection URI with credentials
const uri = 'mongodb+srv://ADMIN:admin123@dbdproject.1bayhpe.mongodb.net/';
const client = new MongoClient(uri);

// Function to fetch and display all products from the 'Products' collection
async function displayProducts() {
  try {
    // Connect to the MongoDB cluster
    await client.connect();

    // Select the 'eCommerce' database and the 'Products' collection
    const database = client.db('eCommerce');
    const products = database.collection('Products');

    // Retrieve all documents (products) from the collection
    const cursor = products.find({});

    // Convert the cursor into an array of product objects
    const results = await cursor.toArray();

    // Loop through and print each product to the console
    results.forEach(product => console.log(product));
  } catch (err) {
    // Handle and display any errors that occur during the process
    console.error('Error:', err);
  } finally {
    // Ensure the MongoDB connection is closed after operation
    await client.close();
  }
}

// Invoke the function to display products
displayProducts();
