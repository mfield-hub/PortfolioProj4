const { MongoClient, ObjectId } = require("mongodb");
const fs = require("fs");

const uri = "mongodb://localhost:27017";
const dbName = "ecommerce";

function convertOids(obj) {
  if (Array.isArray(obj)) {
    return obj.map(convertOids);
  } else if (obj && typeof obj === "object") {
    if ("$oid" in obj) {
      return new ObjectId(obj["$oid"]);
    }

    const newObj = {};
    for (const key in obj) {
      newObj[key] = convertOids(obj[key]);
    }
    return newObj;
  } else {
    return obj;
  }
}

async function run() {
  const client = new MongoClient(uri);
  try {
    await client.connect();
    const db = client.db(dbName);

    const seedData = JSON.parse(fs.readFileSync("../data/seed_data.json", "utf8"));

    const collections = await db.listCollections().toArray();
    for (const { name } of collections) {
      await db.collection(name).deleteMany({});
      console.log(`Cleared collection: ${name}`);
    }

    for (const collectionEntry of seedData) {
      const { collection, documents } = collectionEntry;
      const convertedDocs = convertOids(documents);
      const result = await db.collection(collection).insertMany(convertedDocs);
      console.log(`Inserted into ${collection}: ${result.insertedCount} documents`);
    }
  } catch (err) {
    console.error("Seeding failed:", err);
  } finally {
    await client.close();
  }
}

run();
