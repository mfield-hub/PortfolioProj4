const { MongoClient } = require('mongodb');

// MongoDB connection URI with credentials
const uri = 'mongodb+srv://ADMIN:admin123@dbdproject.1bayhpe.mongodb.net/';
const client = new MongoClient(uri);

// Function to filter products whose price is greater than a given value
async function filter() {
  try {
    // Connect to the MongoDB cluster
    await client.connect();

    // Select the 'eCommerce' database and 'Products' collection
    const database = client.db('eCommerce');
    const products = database.collection('Products');

    // Define the price threshold
    const givenPrice = 39;

    // Retrieve all products from the collection
    const cursor = products.find({});
    const results = await cursor.toArray();

    // Initialize an array to hold filtered products
    let filtered = [];

    // Loop through each product and check if it meets the filter condition
    for (let i = 0; i < results.length; i++) {
      if (results[i].price > givenPrice) {
        filtered.push(results[i]);  // Add matching product to the filtered array
      }
    }

    // Print the filtered products
    console.log(filtered);

  } catch (err) {
    // Log any errors that occur
    console.error('Error:', err);
  } finally {
    // Close the MongoDB connection
    await client.close();
  }
}

// Run the filter function
filter();
