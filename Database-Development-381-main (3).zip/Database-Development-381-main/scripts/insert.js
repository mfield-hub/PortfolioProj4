const { MongoClient } = require('mongodb');

//the URI we use to connect to the database
const uri = 'mongodb+srv://ADMIN:admin123@dbdproject.1bayhpe.mongodb.net/';
const client = new MongoClient(uri);

async function insertSampleData() {
    
    //Using try function to avoid hard crash
    try {
        //Making a connection to the database
        await client.connect();
        const db = client.db('eCommerce');

        //Sample data to test the function
        const sampleUsers = [
            {
                _id: { oid: "664edcdd1c9d440000000001" },
                name: "Alice Smith",
                email: "alice@example.com",
                password_hash: "hashed_pw_smith",
                address: {
                street: "123 Main St",
                city: "Wonderland",
                zip: "12345"
                },
                created_at: "2024-01-15T00:00:00Z"
            },
            {
                _id: { oid: "664edcdd1c9d440000000002" },
                name: "Bob Johnson",
                email: "bob@example.com",
                password_hash: "hashed_pw_bob",
                address: {
                street: "456 Oak St",
                city: "Springfield",
                zip: "67890"
                },
                created_at: "2024-02-20T00:00:00Z"
            }
        ];
        //Inserting the sample data
        await db.collection("Users").insertMany(sampleUsers);

        console.log("YAY IT WORKED");
    } catch (error){
        //Display error if caught
        console.log(error);
    } finally {
        //Closes client connection
        await client.close();
    }
}
//Run function
insertSampleData();