const { MongoClient } = require('mongodb');

// MongoDB connection URI with admin credentials
const uri = 'mongodb+srv://ADMIN:admin123@dbdproject.1bayhpe.mongodb.net/';
const client = new MongoClient(uri);

// Function to display all orders from the 'Orders' collection
async function displayOrders() {
  try {
    // Connect to the MongoDB cluster
    await client.connect();

    // Access the 'eCommerce' database and the 'Orders' collection
    const database = client.db('eCommerce');
    const orders = database.collection('Orders');

    // Find all documents (orders) in the collection
    const cursor = orders.find({});

    // Convert the cursor into an array of order objects
    const results = await cursor.toArray();

    // Loop through each order and print it to the console
    results.forEach(order => console.log(order));
  } catch (err) {
    // Catch and log any errors that occur during the operation
    console.error('Error:', err);
  } finally {
    // Ensure the database connection is closed
    await client.close();
  }
}

// Invoke the function to display all orders
displayOrders();
