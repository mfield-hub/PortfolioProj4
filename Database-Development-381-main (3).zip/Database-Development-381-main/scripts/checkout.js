const { MongoClient } = require('mongodb');

// MongoDB connection URI with credentials
const uri = 'mongodb+srv://ADMIN:admin123@dbdproject.1bayhpe.mongodb.net/';
const client = new MongoClient(uri);

// Main checkout function
async function checkout() {
    try {
        // Connect to MongoDB cluster
        await client.connect();

        // Select the 'eCommerce' database and 'Products' collection
        const db = client.db('eCommerce');
        const products = db.collection('Products');

        // Define the product to be purchased
        const itemName = "Wireless Mouse";

        // Define a mock order
        const order = [
            {
                _id: {
                    oid: "3f8f17075741485d9ed2c792"
                },
                user_id: {
                    oid: "f029292245d9487693c1cb63"
                },
                items: [
                    {
                        product_id: {
                            oid: "66888f04d55a4c82a31df5f1"
                        },
                        quantity: 3,
                        price: 29.99
                    }
                ],
                status: "Processing",
                total: 89.97,
                created_at: "2025-05-17T13:09:03.174576Z"
            }
        ];

        // Find the product by title
        const cursor = products.find({ title: itemName });

        // Convert cursor to array to retrieve the product document
        const test = await cursor.toArray();

        // Get current stock of the product
        var stockNum = test[0].stock;

        // Check if there is enough stock to fulfill the order
        if (stockNum < order[0].items[0].quantity) {
            // Not enough stock, exit the function (order not processed)
            return;
        } else {
            // Enough stock, update order status and reduce stock
            order[0].status = "Processed";
            stockNum -= order[0].items[0].quantity;

            // Update stock value in the Products collection
            products.updateOne(
                { title: itemName },
                { $set: { stock: stockNum } }
            );
        }

        // Insert the processed order into the 'Orders' collection
        await db.collection("Orders").insertMany(order);

        // Confirmation message
        console.log("Order Processed");

    } catch (error) {
        // Log any errors that occur
        console.log(error);
    } finally {
        // Close the MongoDB connection
        client.close();
    }
}

// Call the checkout function
checkout();
