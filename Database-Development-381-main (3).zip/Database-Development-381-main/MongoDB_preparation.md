# MongoDB preparation

In order to call Mongosh and Mongod in the console, both need to have system environment variables assigned to them.

## Step 1: Download MongoDB Shell (Mongosh)

[Download the .ZIP folder at www.mongo.com]('https://www.mongodb.com/try/download/compass')

<img src=".\images\Msh0.png" alt="Download Page" width="30%" />

## Step 2: Setup MongoDB Shell Environmental Variable

2.1 Extract the folder to a permanent location:

<img src=".\images\Msh1.png" alt="Permanent Path" width="30%" />

2.2 Copy the path of the Bin folder

![Bin Directory](.\images\Msh2.png)

2.3 Press Start and search for System environments

2.4 Select 'Edit the System Environment Variables'

![Edit the System Environment Variables](.\images\Msh3.png)

2.5 Select 'Environmental Variables' in the lower right (Windows does not allow screenshots from here)

2.6 In the <b>bottommost</b> panel, select 'Path' and press 'Edit', then 'New'

2.7 Paste the path you copied in step 2.2

2.8 Select OK repeatedly until you exit the setting completely

## Step 3: Setup MongoDB Server Process (Mongod)

3.1 Navigate to your MongoDB installation Directory, find the bin folder and copy it

![Bin Directory](.\images\Msd1.png)

3.2 Repeat step 2.3 to 2.5 (Edit the System Environment Variables)

3.3 In the <b>topmost</b> panel, select 'Path' and press 'Edit', then 'New'

3.4 Paste the path you copied in step 3.1

3.5 Select OK repeatedly until you exit the setting completely
