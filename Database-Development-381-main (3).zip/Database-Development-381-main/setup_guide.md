#  MongoDB E-commerce Setup Guide

## Prerequisites
- MongoDB installed locally *
- Mongosh installed locally *
- MongoDB Compass installed locally
- Node.js installed 
- VS Code (optional but recommended)

### *Special setup required, see MongoDB_preparation.md

## Folder Structure

<pre>
project-root/
│
├── data/
    │
    ├── data_model.json          
    └── seed_data.json 
├── scripts/
    │           
    └── seed.js                  
├── setup_guide.md
├── MongoDB_preparation.md          
└── README.md                
</pre>

## Step 1: Create Local MongoDB Data Directory
Open PowerShell:
<pre>mkdir C:\mongodb\data\db </pre>

## Step 1.5: Open 3 instances of a terminal
3 different terminals will be required for:
- Running the server
- Interacting with the Database before/without using Compass
- A blank terminal for executing the script

<img src=".\images\terminal.png" alt="Connection Enter" />

## Step 2: Start MongoDB with Replication Enabled
In the first terminal, start and replicate the database with:

<pre>mongod --replSet rs0 --dbpath "C:\mongodb\data\db" --port 27017</pre>

A wall of text is completely normal. Keep this running.

The procedure may be interrupted and stopped with Ctrl + C

## Step 3: Initiate Replica Set

3.1 In a new terminal, launch mongosh:
<pre>mongosh</pre>

3.2 Initiate:
<pre>rs.initiate()</pre>

3.3 Verify:
<pre>rs.status()</pre>

"ok": 1  should be visible in the output, indicating success

<img src=".\images\Ok.png" alt="Ok code" />


## Step 4: Initiate Replica Set

Use the seed script in the non mongosh (default) terminal
<pre>node scripts/seed.js</pre>

## Step 5: Verification
Using Mongosh:

<pre>use ecommerce 
     db.products.find().pretty() 
     db.users.find().pretty()
</pre>

Other tables can be viewed with this method, simply replace the name in the function: "db.[TableName].find().pretty()"

## Optional Step: Cleaning
Using Mongosh:

<pre>
use ecommerce
db.dropDatabase()
</pre>

## Step 6: Connect MongoDB Compass for GUI

Click 'Add new Connection'

<img src=".\images\Compass1.png" alt="Connection Enter" width="30%" />

Enter connection string
Any name and color will do

<img src=".\images\Compass2.png" alt="Connection string and properties" width="30%" />

Access Tables on the left hand side

<img src=".\images\Compass3.png" alt="Tables location on the left" height="30%" />





